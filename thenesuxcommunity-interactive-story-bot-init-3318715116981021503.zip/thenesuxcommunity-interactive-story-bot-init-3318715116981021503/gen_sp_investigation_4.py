import json
import os

def generate_story():
    story = {
        "id": 104,
        "title": "جريمة في الظلال: لغز الرسالة المشفرة",
        "theme": "التحقيق الجنائي (عقول إجرامية)",
        "series": 4,
        "game_mode": "single",
        "description": "أنت المحقق الخبير 'يوسف'. قاتل متسلسل يطلق على نفسه اسم (الظل) ترك جثة جديدة في وسط المدينة مع رسالة مشفرة. يعتقد رئيسك أن القاتل يختبر ذكاءك. هدفك: فك شفرة الرسالة، تتبع مسارات القاتل المعقدة، وإنقاذ الضحية التالية قبل فوات الأوان. (تلميح: انتبه جيداً للأرقام والرموز في النص، ستحتاجها لفتح أبواب أو صناديق).",
        "start_scene": "scene_01_crime_scene",
        "image_url": "https://images.unsplash.com/photo-1542282088-fe8426682b8f?q=80&w=600&auto=format&fit=crop",
        "scenes": [
            {
                "id": "scene_01_crime_scene",
                "title": "الجثة الأولى والرسالة",
                "text": "الساعة 3 فجراً. تقف أمام جثة معلقة أسفل جسر مهجور. الضحية هو (مازن)، صحفي استقصائي. لا توجد آثار مقاومة، بل يبدو كأنه تم تخديره أولاً. تجد في جيبه ورقة مطوية مكتوب عليها: 'الحقيقة تُدفن دائماً في الطابق الـ 13. لكن الرمز هو عدد الحروف في اسمي الذي لا أكتبه.' كيف تتعامل مع مسرح الجريمة أولاً؟",
                "image_url": "https://images.unsplash.com/photo-1599557053530-eb378bdf1b06?q=80&w=600&auto=format&fit=crop",
                "choices": [
                    {
                        "text": "[البحث في ملابس الضحية] 'ربما هناك شيء آخر غير الورقة.'",
                        "next_scene": "scene_02_pockets",
                        "color": "primary",
                        "points_reward": 5
                    },
                    {
                        "text": "[تحليل الرسالة فوراً] 'القاتل ترك تلميحاً للطابق 13.'",
                        "next_scene": "scene_02_riddle",
                        "color": "secondary",
                        "points_reward": 5
                    },
                    {
                        "text": "[استدعاء الصحافة] 'سأستغل الإعلام لاستفزاز القاتل.'",
                        "next_scene": "scene_fail_press",
                        "color": "danger",
                        "points_reward": -10
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_02_pockets",
                "title": "مفتاح خفي",
                "text": "تفتش جيوب مازن بعناية وتجد مفتاحاً صغيراً برقم (402) ومحفظة فارغة تماماً من النقود والبطاقات. المفتاح يبدو وكأنه لصندوق بريد أو خزانة في محطة قطار.",
                "choices": [
                    {
                        "text": "[الذهاب لمحطة القطار فوراً] 'يجب أن نرى ما يخفيه الصندوق 402.'",
                        "next_scene": "scene_03_train_station",
                        "color": "primary",
                        "points_reward": 10
                    },
                    {
                        "text": "[العودة لتحليل الرسالة] 'المفتاح مهم، لكن الرسالة تشير للطابق 13.'",
                        "next_scene": "scene_02_riddle",
                        "color": "secondary",
                        "points_reward": 0
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_02_riddle",
                "title": "لغز الطابق 13",
                "text": "تفكر في الرسالة: 'الطابق 13'. معظم المباني في هذه المدينة لا تحتوي على طابق 13 (يتم تخطيه لأسباب تشاؤمية)، باستثناء مبنى واحد: 'برج الصحافة' حيث كان يعمل الضحية. لكن ماذا عن الرمز؟ 'عدد الحروف في اسمي الذي لا أكتبه'. القاتل يسمي نفسه (الظل).",
                "choices": [
                    {
                        "text": "[الذهاب لبرج الصحافة مباشرة] 'الرمز هو 4 (عدد حروف كلمة الظل).'",
                        "next_scene": "scene_04_press_tower",
                        "color": "primary",
                        "points_reward": 10
                    },
                    {
                        "text": "[الذهاب لبرج الصحافة] 'الرمز هو 3 (عدد حروف كلمة ظل).'",
                        "next_scene": "scene_04_press_tower",
                        "color": "primary",
                        "points_reward": 5
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_03_train_station",
                "title": "صندوق 402",
                "text": "تصل إلى محطة القطار المركزية. الخزانة 402 تحتوي على حقيبة ظهر. تفتحها بحذر لتجد بداخلها جهاز كمبيوتر محمول (لابتوب) مقفل بكلمة مرور، وملفاً يحتوي على صور لشخصيات عامة، أحدهم قاضٍ معروف، وعليه علامة X حمراء كبيرة.",
                "choices": [
                    {
                        "text": "[إرسال اللابتوب للمعمل] 'سيقومون باختراقه.'",
                        "next_scene": "scene_05_lab",
                        "color": "secondary",
                        "points_reward": 0
                    },
                    {
                        "text": "[الذهاب لمنزل القاضي فوراً] 'القاتل وضع هدفه التالي!'",
                        "next_scene": "scene_06_judge_house",
                        "color": "primary",
                        "points_reward": 15
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_04_press_tower",
                "title": "مكتب الصحفي المفقود",
                "text": "تدخل برج الصحافة ليلاً وتصل للطابق 13. مكتب مازن فوضوي. تجد خزنة صغيرة على الحائط تتطلب رمزاً من رقم واحد.",
                "choices": [
                    {
                        "text": "إدخال الرقم (4) بناءً على (الظل).",
                        "next_scene": "scene_07_safe_open",
                        "color": "success",
                        "points_reward": 10
                    },
                    {
                        "text": "إدخال الرقم (3) بناءً على (ظل).",
                        "next_scene": "scene_fail_safe",
                        "color": "danger",
                        "points_reward": -10
                    },
                    {
                        "text": "محاولة كسر الخزنة.",
                        "next_scene": "scene_fail_safe_force",
                        "color": "danger",
                        "points_reward": -15
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_05_lab",
                "title": "تأخير قاتل",
                "text": "يستغرق المعمل 12 ساعة لاختراق اللابتوب. عندما تفتحه، تجد ملفاً يشير إلى أن القاضي (منصور) هو الهدف التالي، وموعد التنفيذ كان... منذ ساعتين. لقد تأخرت.",
                "choices": [
                    {
                        "text": "الذهاب لمسرح الجريمة الثاني...",
                        "next_scene": "scene_fail_judge_dead",
                        "color": "danger",
                        "points_reward": -20
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_06_judge_house",
                "title": "سباق مع الزمن",
                "text": "تصل إلى فيلا القاضي منصور. الأبواب مفتوحة والكهرباء مقطوعة. تسحب سلاحك وتدخل بحذر. تسمع صوت صراع من الطابق العلوي.",
                "choices": [
                    {
                        "text": "[الركض سريعاً للطابق العلوي] 'لا وقت للانتظار!'",
                        "next_scene": "scene_08_ambush",
                        "color": "danger",
                        "points_reward": -5
                    },
                    {
                        "text": "[الصعود بحذر وصمت] 'هذا فخ محتمل، يجب أن أكون متيقظاً.'",
                        "next_scene": "scene_08_stealth",
                        "color": "primary",
                        "points_reward": 10
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_07_safe_open",
                "title": "محتويات الخزنة",
                "text": "تفتح الخزنة. تجد بداخلها ملفاً ضخماً بعنوان (العدالة المظلمة). الملف يفضح قاضياً معروفاً يقبل الرشاوى. وفي الصفحة الأخيرة، تجد ملاحظة جديدة بخط القاتل: 'لقد وجدت الحقيقة، لكن هل ستنقذ الفاسد؟ موعدنا في منزله.'",
                "choices": [
                    {
                        "text": "الاتصال بالشرطة وتطويق منزل القاضي فوراً.",
                        "next_scene": "scene_09_police_arrive",
                        "color": "primary",
                        "points_reward": 10
                    },
                    {
                        "text": "الذهاب بمفردك لمواجهة القاتل.",
                        "next_scene": "scene_06_judge_house",
                        "color": "secondary",
                        "points_reward": 5
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_08_ambush",
                "title": "كمين الظل",
                "text": "تركض كالأعمى في الظلام. تتعثر بسلك رفيع مشدود على الدرج، وتسقط بقوة لتفقد وعيك. عندما تستيقظ، تجد نفسك مقيداً والقاضي مقتولاً بجانبك. القاتل هرب וتركك كمتهم رئيسي.",
                "choices": [
                    {
                        "text": "نهاية مأساوية...",
                        "next_scene": "scene_fail_framed",
                        "color": "danger",
                        "points_reward": 0
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_08_stealth",
                "title": "مواجهة الظل",
                "text": "تصعد بحذر. تتفادى سلكاً مفخخاً على الدرج. تصل للغرفة لتجد رجلاً مقنعاً يضع حبلاً حول عنق القاضي. توجه سلاحك وتصرخ: 'شرطة! اترك السلاح.'",
                "choices": [
                    {
                        "text": "[إطلاق النار فوراً]",
                        "next_scene": "scene_10_shoot",
                        "color": "danger",
                        "points_reward": -10
                    },
                    {
                        "text": "[محاولة التفاوض] 'لقد كشفت لعبتك. لا داعي لمزيد من الدماء.'",
                        "next_scene": "scene_10_talk",
                        "color": "primary",
                        "points_reward": 10
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_09_police_arrive",
                "title": "تأمين محكم",
                "text": "تصل سيارات الشرطة وتطوق الفيلا بالكامل. القاتل يدرك أنه محاصر. يحاول الهرب من السطح لكن المروحيات تكشفه.",
                "choices": [
                    {
                        "text": "الصعود للسطح للقبض عليه بنفسك.",
                        "next_scene": "scene_win_perfect",
                        "required_points": 25,
                        "color": "success",
                        "points_reward": 10
                    },
                    {
                        "text": "إعطاء الأمر للقناصة بالتدخل.",
                        "next_scene": "scene_win_sniper",
                        "color": "secondary",
                        "points_reward": 0
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_10_shoot",
                "title": "رصاصة طائشة",
                "text": "تطلق النار في الظلام، لكن القاتل كان يستخدم القاضي كدرع. تصيب القاضي بكتفه، ويستغل القاتل الفوضى ليقفز من النافذة ويختفي في الغابة المحيطة.",
                "choices": [
                    {
                        "text": "ملاحقته في الغابة...",
                        "next_scene": "scene_fail_escape",
                        "color": "danger",
                        "points_reward": 0
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_10_talk",
                "title": "حوار العقول",
                "text": "يبتسم المقنع من خلف قناعه. 'لقد حليت لغزي الأول بسرعة يا يوسف. هذا الرجل فاسد، وأنت تعرف ذلك.'",
                "choices": [
                    {
                        "text": "'العدالة لا تتحقق بالقتل. استسلم وسنحاكمه بالأدلة التي وجدتها.'",
                        "next_scene": "scene_win_arrest",
                        "required_points": 20,
                        "color": "success",
                        "points_reward": 15
                    },
                    {
                        "text": "'أنت مجنون، سأطلق النار!'",
                        "next_scene": "scene_10_shoot",
                        "color": "danger",
                        "points_reward": -5
                    }
                ],
                "is_ending": False
            },
            {
                "id": "scene_fail_press",
                "title": "النهاية: استفزاز قاتل",
                "text": "تصريحك للإعلام جعل القاتل يغضب. بدلاً من ترك تلميحات، بدأ بقتل الضحايا عشوائياً. تم سحب القضية منك وإيقافك عن العمل لسوء التقدير. (لقد خسرت).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_fail_safe",
                "title": "النهاية: إنذار الخزنة",
                "text": "الرقم 3 كان خاطئاً. الخزنة مفخخة وتطلق إنذاراً عالياً يتلف الأوراق بداخلها عبر مادة كيميائية حارقة. لقد خسرت الدليل الوحيد وتوقفت القضية. (لقد خسرت).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_fail_safe_force",
                "title": "النهاية: القوة الغاشمة",
                "text": "محاولتك لكسر الخزنة أدت لتفعيل نظام التدمير الذاتي بداخلها. احترقت الملفات وضاع الدليل. (لقد خسرت).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_fail_judge_dead",
                "title": "النهاية: خطوة متأخرة",
                "text": "الاعتماد على المعمل جعلك تخسر الوقت الثمين. القاضي قُتل والقاتل تبخر. أنت تواجه الآن تحقيقاً داخلياً حول بطء استجابتك. (لقد خسرت).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_fail_framed",
                "title": "النهاية: المحقق المتهم",
                "text": "استيقظت لتجد سلاحك بجانب الجثة. القاتل لفّق لك التهمة ووضع أموالاً في حسابك لتبدو كعملية مأجورة. أنت الآن في السجن. (لقد خسرت بقسوة).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_fail_escape",
                "title": "النهاية: هروب الظل",
                "text": "لم تتمكن من اللحاق به في الغابة. القاضي مصاب وأنت فقدت القاتل الذي لن يظهر مجدداً. تعتبر هذه هزيمة مهينة لك. (لقد خسرت).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_win_arrest",
                "title": "النهاية: القبض على الظل",
                "text": "القاتل يستسلم بعد أن أدرك أنك تمتلك أدلة الفساد وأن رسالته وصلت. تم القبض عليه ومحاكمة القاضي أيضاً. أصبحت بطلاً في قسم الشرطة. (لقد فزت بذكاء).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_win_sniper",
                "title": "النهاية: عدالة دموية",
                "text": "القناصة يطلقون النار على القاتل على السطح، ويسقط صريعاً. أنقذت القاضي، لكنك لم تعرف هوية القاتل الحقيقية أبداً. (لقد فزت جزئياً).",
                "choices": [],
                "is_ending": True
            },
            {
                "id": "scene_win_perfect",
                "title": "النهاية: انتصار ساحق",
                "text": "بفضل تتبعك السريع للأدلة، تصعد للسطح وتشتبك معه بالأيدي. تنجح في شل حركته ونزع قناعه. لقد قبضت على (الظل) حياً، وأسقطت شبكة الفساد بأكملها. نهاية مثالية لمسيرتك! (لقد فزت بأفضل نهاية).",
                "choices": [],
                "is_ending": True
            }
        ]
    }

    os.makedirs("data/stories", exist_ok=True)
    with open("data/stories/sp_investigation_4.json", "w", encoding="utf-8") as f:
        json.dump(story, f, ensure_ascii=False, indent=4)
    print("Story 4 generated successfully!")

if __name__ == "__main__":
    generate_story()
